package Examen;

public enum TipoEntorno {

	EDF,EPP;
}
